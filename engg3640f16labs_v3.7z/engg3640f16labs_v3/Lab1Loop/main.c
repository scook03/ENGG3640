/*
 * main.c provides a print functionality and calls assembly pseudo-main
 * for Lab1 ENGG3640
*/

#include <stdio.h>
#include "board.h"
#include "gpio_pins.h"
#include "fsl_debug_console.h"
#include <cstddef>

extern void asmmain(void);
void my_fprint(char* d)
{
	PRINTF("%ds\r\n", d);
}

int main(void)
{
	hardware_init();
	asmmain();
}
